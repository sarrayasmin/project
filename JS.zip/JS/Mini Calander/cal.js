const monthNameEl = document.getElementById('monthName');
const dayNameEl = document.getElementById('dayName');
const dayNumberEl = document.getElementById('dayNumber');
const yearEl = document.getElementById('year');
const date = new Date();

monthNameEl.innerText = date.toLocaleString('en',{month:'long'})
dayNameEl.innerText = date.toLocaleString('en',{weekday:'long'})
dayNumberEl.innerText = date.getDate()
yearEl.innerText = date.getFullYear()

// const monthNames = ["January", "February", "March", "April", "May", "June",
//     "July", "August", "September", "October", "November", "December"
//   ];
  