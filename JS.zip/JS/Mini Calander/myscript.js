const monthnameEl = document.getElementById('month_name');
const daynameEl = document.getElementById('day_name');
const daynumberEl = document.getElementById('day_number');
const yearEl = document.getElementById('tear');

const date = new Date();
const month = date.getMonth();
monthnameEl.innerText = date.toLocaleString('en',{
    month:'long'});
daynameEl.innerText = date.toLocaleString('en',{
    weekday:'long'
});
daynumberEl.innerText = date.getDate()
yearEl.innerText = date.getUTCFullYear()