const monthEL = document.getElementById('monthName');
const dayNameEL = document.getElementById('dayName');
const dayNumEL = document.getElementById('dayNumber');
const yearEL = document.getElementById('year');
const date = new Date();

monthEL.innerText = date.toLocaleString('en',{month:('long')})
dayNameEL.innerText = date.toLocaleString('en',{weekday:('long')})
dayNumEL.innerText = date.getDate()
yearEL.innerText = date.getFullYear()