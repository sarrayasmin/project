const monthNameEl = document.getElementById('monthName');
const dayNameEl = document.getElementById('dayName');
const dayNumberEl = document.getElementById('dayNumber');
const yearEl = document.getElementById('year');
const date = new Date();

const monthEl = ['January','February','March','April','May','June','July','August','September','Octobar','November','Decembar'];
const dayEl =['Sun','Mon','Thu','Wed','Thr','Fri','Sat']
// monthNameEl.innerText= date.toLocaleString('en',{month:'long'});
// dayNameEl.innerText= date.toLocaleString('en',{weekday:'long'});
dayNumberEl.innerText = date.getDate();
yearEl.innerText= date.getFullYear();
monthNameEl.innerText= monthEl[date.getMonth()];
dayNameEl.innerText=dayEl[date.getDay()]